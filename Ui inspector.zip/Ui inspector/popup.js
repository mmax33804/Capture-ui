const logoSvgs = {
  "base": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><rect x="6" y="8" width="52" height="48" /><line x1="6" y1="22" x2="58" y2="22" /><rect x="20" y="32" width="24" height="16" stroke-dasharray="4 4"><animate attributeName="stroke-dashoffset" values="0;8" dur="1s" repeatCount="indefinite"/></rect><circle cx="32" cy="40" r="3" fill="var(--bg)" stroke="none"><animate attributeName="opacity" values="1;0;1" dur="2s" repeatCount="indefinite"/></circle></svg>`,
  "dashed": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><rect x="6" y="8" width="52" height="48" stroke-dasharray="8 8"><animate attributeName="stroke-dashoffset" from="0" to="16" dur="1s" repeatCount="indefinite"/></rect><circle cx="32" cy="32" r="8" /></svg>`,
  "thick": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="8" stroke-linecap="square" stroke-linejoin="miter"><rect x="10" y="10" width="44" height="44" /><circle cx="32" cy="32" r="6" fill="var(--bg)" stroke="none"><animate attributeName="r" values="6;2;6" dur="1.5s" repeatCount="indefinite"/></circle></svg>`,
  "pulse": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><rect x="6" y="8" width="52" height="48"><animate attributeName="stroke-opacity" values="1;0.2;1" dur="2s" repeatCount="indefinite"/></rect><rect x="16" y="18" width="32" height="28" opacity="0.5" /><circle cx="32" cy="32" r="4" fill="var(--bg)" stroke="none" /></svg>`,
  "target": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><path d="M16 6 L6 6 L6 16 M48 6 L58 6 L58 16 M16 58 L6 58 L6 48 M48 58 L58 58 L58 48" /><circle cx="32" cy="32" r="6"><animate attributeName="r" values="6;8;6" dur="1.5s" repeatCount="indefinite"/></circle></svg>`,
  "crosshair": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><line x1="32" y1="0" x2="32" y2="64" /><line x1="0" y1="32" x2="64" y2="32" /><circle cx="32" cy="32" r="16"><animate attributeName="r" values="16;12;16" dur="2s" repeatCount="indefinite"/></circle></svg>`,
  "inverted": `<svg width="32" height="32" viewBox="0 0 64 64" fill="var(--bg)" stroke="var(--fg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><rect x="6" y="8" width="52" height="48" /><circle cx="32" cy="32" r="12" fill="var(--fg)" stroke="none"><animate attributeName="r" values="12;6;12" dur="2s" repeatCount="indefinite"/></circle></svg>`,
  "scanline": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><rect x="4" y="12" width="56" height="40" /><line x1="4" y1="32" x2="60" y2="32" stroke-width="6" opacity="0"><animate attributeName="y1" values="12;52;12" dur="1.7s" repeatCount="indefinite"/><animate attributeName="y2" values="12;52;12" dur="1.7s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.7;0;0" keyTimes="0;0.1;0.2;1" dur="2.1s" repeatCount="indefinite" /></line><circle cx="32" cy="58" r="2" fill="var(--bg)" stroke="none" /></svg>`,
  "glitch": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><rect x="4" y="10" width="50" height="44" /><rect x="10" y="8" width="50" height="44" opacity="0.5"><animate attributeName="x" values="10;8;12;10" dur="0.2s" repeatCount="indefinite"/></rect><line x1="0" y1="32" x2="64" y2="32" stroke-dasharray="4 8" /></svg>`,
  "hacker": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><rect x="4" y="8" width="56" height="48" /><text x="12" y="24" fill="var(--bg)" stroke="none" font-family="monospace" font-size="12" opacity="0.3">1011<animate attributeName="y" values="0;60" dur="2s" repeatCount="indefinite"/></text><text x="40" y="44" fill="var(--bg)" stroke="none" font-family="monospace" font-size="12" opacity="0.4">01<animate attributeName="y" values="-10;60" dur="3s" repeatCount="indefinite"/></text><text x="12" y="44" fill="var(--bg)" stroke="none" font-family="monospace" font-size="28" font-weight="bold">>_<animate attributeName="opacity" values="1;0;1" dur="1s" repeatCount="indefinite" /></text></svg>`,
  "skull": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><path d="M16 48 L16 32 C16 16 48 16 48 32 L48 48 L40 48 L40 56 L24 56 L24 48 Z"><animate attributeName="stroke" values="var(--bg);var(--accent);var(--bg)" dur="3s" repeatCount="indefinite"/></path><circle cx="24" cy="32" r="4"><animate attributeName="r" values="4;2;4" dur="2s" repeatCount="indefinite"/></circle><circle cx="40" cy="32" r="4"><animate attributeName="r" values="4;2;4" dur="2s" repeatCount="indefinite"/></circle><line x1="32" y1="44" x2="32" y2="48" /></svg>`,
  "camera": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><rect x="4" y="20" width="56" height="36" /><circle cx="32" cy="38" r="10"><animate attributeName="r" values="10;6;10" dur="2s" repeatCount="indefinite"/></circle><rect x="12" y="12" width="16" height="8" /><line x1="48" y1="28" x2="52" y2="28" stroke-width="6"><animate attributeName="stroke" values="var(--bg);var(--accent);var(--bg)" dur="1s" repeatCount="indefinite"/></line></svg>`,
  "alien": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><path d="M32 8 C12 8 8 32 16 56 L48 56 C56 32 52 8 32 8 Z" /><ellipse cx="22" cy="36" rx="6" ry="10" transform="rotate(-30 22 36)" fill="var(--bg)"><animate attributeName="ry" values="10;2;10" dur="4s" repeatCount="indefinite"/></ellipse><ellipse cx="42" cy="36" rx="6" ry="10" transform="rotate(30 42 36)" fill="var(--bg)"><animate attributeName="ry" values="10;2;10" dur="4s" repeatCount="indefinite"/></ellipse></svg>`,
  "ghost": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><path d="M12 56 L12 28 C12 12 52 12 52 28 L52 56 L44 48 L36 56 L28 48 L20 56 Z"><animate attributeName="d" values="M12 56 L12 28 C12 12 52 12 52 28 L52 56 L44 48 L36 56 L28 48 L20 56 Z;M12 52 L12 28 C12 12 52 12 52 28 L52 52 L44 60 L36 52 L28 60 L20 52 Z;M12 56 L12 28 C12 12 52 12 52 28 L52 56 L44 48 L36 56 L28 48 L20 56 Z" dur="2s" repeatCount="indefinite"/></path><circle cx="24" cy="28" r="4" fill="var(--bg)" /><circle cx="40" cy="28" r="4" fill="var(--bg)" /></svg>`,
  "eye": `<svg width="32" height="32" viewBox="0 0 64 64" fill="none" stroke="var(--bg)" stroke-width="4" stroke-linecap="square" stroke-linejoin="miter"><path d="M4 32 C16 12 48 12 60 32 C48 52 16 52 4 32 Z" /><circle cx="32" cy="32" r="10" /><circle cx="32" cy="32" r="3" fill="var(--bg)"><animate attributeName="cx" values="32;28;36;32" dur="3s" repeatCount="indefinite"/></circle></svg>`
};
function updateLogoSVG() {
  chrome.storage.local.get({animStyle: "base", logoStyle: "auto"}, (res) => {
    let targetLogo = res.logoStyle;
    if (targetLogo === "auto") targetLogo = res.animStyle;
    const svgHTML = logoSvgs[targetLogo] || logoSvgs["base"];
    const headerIllustration = document.querySelector(".header-illustration");
    if (headerIllustration) {
      headerIllustration.innerHTML = svgHTML;
    }
  });
}

const i18n = {
  "en": {
    "title_element": "Element",
    "desc_element": "Smart Upscale Crop",
    "title_viewport": "Viewport",
    "desc_viewport": "Screen Capture",
    "title_page": "Full Page",
    "desc_page": "Infinite Scroll",
    "view_shortcuts": "SETTINGS & SHORTCUTS",
    "panel_shortcuts": "KEYBOARD SHORTCUTS",
    "short_element": "Capture Element",
    "short_viewport": "Capture Viewport",
    "short_page": "Capture Full Page",
    "short_detach": "Detach Window",
    "frame_style": "Frame Style (10)",
    "style_base": "Base",
    "style_dashed": "Animated Dashed",
    "style_thick": "Thick Brutal",
    "style_pulse": "Pulsing Glow",
    "style_target": "Target Bracket",
    "style_crosshair": "Crosshair Focus",
    "style_inverted": "Inverted Color",
    "style_scanline": "CRT Scanline",
    "style_glitch": "Cyber Glitch",
    "style_hacker": "Terminal Hacker",
    "tooltip_style": "These styles change the visual frame when capturing an element.",
    "popup_logo": "Popup Logo (10)",
    "tooltip_logo": "Change the main logo icon of the popup header.",
    "logo_auto": "Auto (Sync)",
    "logo_skull": "Cyber Skull",
    "logo_camera": "Pro Camera",
    "logo_alien": "Area 51 Alien",
    "logo_ghost": "Spooky Ghost",
    "logo_eye": "All-Seeing Eye",
    "dev_by": "Developed by",
    "dev_and": "and"
  },
  "ro": {
    "title_element": "Element",
    "desc_element": "Selectare Inteligentă",
    "title_viewport": "Vizibil",
    "desc_viewport": "Captură Ecran",
    "title_page": "Pagină",
    "desc_page": "Captură Completă",
    "view_shortcuts": "SETĂRI & SCURTĂTURI",
    "panel_shortcuts": "SCURTĂTURI TASTATURĂ",
    "short_element": "Captură Element",
    "short_viewport": "Captură Ecran",
    "short_page": "Captură Pagină Completă",
    "short_detach": "Detașare Fereastră",
    "frame_style": "Stil Cadru (10)",
    "style_base": "Bază",
    "style_dashed": "Contur Animat",
    "style_thick": "Contur Gros",
    "style_pulse": "Puls Luminos",
    "style_target": "Țintă Scanner",
    "style_crosshair": "Vizor Lunetă",
    "style_inverted": "Efect Negativ",
    "style_scanline": "Monitor Vechi",
    "style_glitch": "Eroare Glitch",
    "style_hacker": "Terminal Hacker",
    "tooltip_style": "Aceste stiluri schimbă aspectul cadrului vizual la capturarea unui element.",
    "popup_logo": "Logo Meniu (10)",
    "tooltip_logo": "Schimbă pictograma principală din antet.",
    "logo_auto": "Auto (Sincronizat)",
    "logo_skull": "Craniu Cyber",
    "logo_camera": "Cameră Pro",
    "logo_alien": "Extraterestru",
    "logo_ghost": "Fantomă",
    "logo_eye": "Ochiul Magic",
    "dev_by": "Dezvoltat de",
    "dev_and": "și"
  },
  "ru": {
    "title_element": "Элемент",
    "desc_element": "Умный Выбор",
    "title_viewport": "Область",
    "desc_viewport": "Видимая Часть",
    "title_page": "Страница",
    "desc_page": "Захват Целиком",
    "view_shortcuts": "НАСТРОЙКИ И ЯРЛЫКИ",
    "panel_shortcuts": "ГОРЯЧИЕ КЛАВИШИ",
    "short_element": "Снимок Элемента",
    "short_viewport": "Снимок Экрана",
    "short_page": "Вся Страница",
    "short_detach": "Открепить Окно",
    "frame_style": "Стиль Рамки (10)",
    "style_base": "Базовый",
    "style_dashed": "Анимированный Пунктир",
    "style_thick": "Толстый Контур",
    "style_pulse": "Светящийся Пульс",
    "style_target": "Прицел Сканера",
    "style_crosshair": "Оптический Прицел",
    "style_inverted": "Негатив",
    "style_scanline": "ЭЛТ Монитор",
    "style_glitch": "Кибер-Глитч",
    "style_hacker": "Терминал Хакера",
    "tooltip_style": "Эти стили меняют внешний вид рамки при захвате элемента.",
    "popup_logo": "Логотип Меню (10)",
    "tooltip_logo": "Изменяет главный значок в заголовке.",
    "logo_auto": "Авто (Синхронно)",
    "logo_skull": "Кибер-Череп",
    "logo_camera": "Pro-Камера",
    "logo_alien": "Пришелец",
    "logo_ghost": "Призрак",
    "logo_eye": "Всевидящее Око",
    "dev_by": "Разработано",
    "dev_and": "и"
  }
};




document.addEventListener("DOMContentLoaded", () => {
  // Alt+M Detach logic & Clean detached mode
chrome.windows.getCurrent((win) => {
  if (win.type === 'popup') {
    document.body.classList.add('detached-mode');
  }
});

document.addEventListener('keydown', (e) => {
  if (e.altKey && (e.key === 'm' || e.key === 'M')) {
    chrome.windows.getCurrent((win) => {
      if (win.type !== 'popup') {
        chrome.windows.create({
          url: 'popup.html',
          type: 'popup',
          width: 336,
          height: 485,
          focused: true
        });
        window.close();
      }
    });
  }
});

  

  const btnElement = document.getElementById("btnElement");
  const btnVisible = document.getElementById("btnVisible");
  const btnPage = document.getElementById("btnPage");
  
  function triggerCapture(type){
    chrome.windows.getCurrent((currentWin) => {
      if (currentWin.type === 'popup') {
        chrome.windows.getLastFocused({populate: true, windowTypes: ['normal']}, (win) => {
          if (win && win.tabs) {
            const activeTab = win.tabs.find(t => t.active);
            if (activeTab) {
              chrome.tabs.sendMessage(activeTab.id, {type: type}).catch(() => {});
              window.close();
            }
          }
        });
      } else {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
          if (tabs && tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {type: type}).catch(() => {});
            window.close();
          }
        });
      }
    });
  }

  if(btnElement) btnElement.addEventListener("click", () => triggerCapture("capture-element"));
  if(btnVisible) btnVisible.addEventListener("click", () => triggerCapture("capture-visible"));
  if(btnPage) btnPage.addEventListener("click", () => triggerCapture("capture-page"));

  const infoBtn = document.getElementById("infoBtn");
  const closePanelBtn = document.getElementById("closePanelBtn");
  const shortcutsPanel = document.getElementById("shortcutsPanel");

  if(infoBtn) infoBtn.addEventListener("click", () => {
    shortcutsPanel.classList.add("open");
  });

  if(closePanelBtn) closePanelBtn.addEventListener("click", () => {
    shortcutsPanel.classList.remove("open");
  });

  const btns = document.querySelectorAll(".edit-shortcut");
  btns.forEach(btn => {
    btn.addEventListener("click", () => {
      chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
    });
  });

  let currentLang = "en";
  const langBtns = document.querySelectorAll(".lang-btn");

  const customSelect = document.getElementById("animCustomSelect");
  let selected = null, items = null, options = null;
  if (customSelect) {
    selected = document.getElementById("animSelectedLabel");
    items = customSelect.querySelector(".select-items");
    options = items.querySelectorAll("div");
  }

  const logoSelect = document.getElementById("logoCustomSelect");
  let logoSelected = null, logoItems = null, logoOptions = null;
  if (logoSelect) {
    logoSelected = document.getElementById("logoSelectedLabel");
    logoItems = logoSelect.querySelector(".select-items");
    logoOptions = logoItems.querySelectorAll("div");
  }

  function updateLanguage(lang) {
    currentLang = lang;
    const dict = i18n[lang] || i18n["en"];
    
    document.querySelectorAll("[data-i18n]").forEach(el => {
      const key = el.getAttribute("data-i18n");
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });

    langBtns.forEach(btn => {
      if (btn.getAttribute("data-lang") === lang) {
        btn.style.opacity = "1";
        btn.style.color = "var(--accent)";
        btn.style.borderColor = "var(--accent)";
      } else {
        btn.style.opacity = "0.5";
        btn.style.color = "#FFFFFF";
        btn.style.borderColor = "transparent";
      }
    });

    if (customSelect) {
      chrome.storage.local.get({animStyle: "base"}, (res) => {
        const match = Array.from(options).find(o => o.getAttribute("data-val") === res.animStyle);
        if (match) {
          const key = match.getAttribute("data-i18n");
          selected.textContent = dict[key] || match.textContent;
        }
      });
    }

    if (logoSelect) {
      chrome.storage.local.get({logoStyle: "auto"}, (res) => {
        const match = Array.from(logoOptions).find(o => o.getAttribute("data-val") === res.logoStyle);
        if (match) {
          const key = match.getAttribute("data-i18n");
          logoSelected.textContent = dict[key] || match.textContent;
        }
      });
    }
  }

  langBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const lang = btn.getAttribute("data-lang");
      chrome.storage.local.set({ appLang: lang });
      updateLanguage(lang);
    });
  });

  if (customSelect) {
    selected.addEventListener("click", () => {
      items.classList.toggle("select-hide");
    });

    options.forEach(opt => {
      opt.addEventListener("click", () => {
        const val = opt.getAttribute("data-val");
        chrome.storage.local.set({animStyle: val});
        items.classList.add("select-hide");
        
        const dict = i18n[currentLang] || i18n["en"];
        const key = opt.getAttribute("data-i18n");
        selected.textContent = dict[key] || opt.textContent;
        updateLogoSVG();
      });
    });

    document.addEventListener("click", (e) => {
      if (!customSelect.contains(e.target)) {
        items.classList.add("select-hide");
      }
    });
  }

  if (logoSelect) {
    logoSelected.addEventListener("click", () => {
      logoItems.classList.toggle("select-hide");
    });

    logoOptions.forEach(opt => {
      opt.addEventListener("click", () => {
        const val = opt.getAttribute("data-val");
        chrome.storage.local.set({logoStyle: val});
        logoItems.classList.add("select-hide");
        
        const dict = i18n[currentLang] || i18n["en"];
        const key = opt.getAttribute("data-i18n");
        logoSelected.textContent = dict[key] || opt.textContent;
        updateLogoSVG();
      });
    });

    document.addEventListener("click", (e) => {
      if (!logoSelect.contains(e.target)) {
        logoItems.classList.add("select-hide");
      }
    });
  }

  updateLogoSVG();
  chrome.storage.local.get({animStyle: "base", appLang: "en", logoStyle: "auto"}, (res) => {
    updateLanguage(res.appLang);
  });
});