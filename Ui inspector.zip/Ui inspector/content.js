(function(){
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
    if (msg.type === "ping") {
      sendResponse({alive:true});
    }
  });

    let mode = null;
  let frame = null;
  let handles = [];
    let styleEl = null;
  let currentStyle = "base";

  chrome.storage.local.get({animStyle: "base"}, (res) => {
    updateStyle(res.animStyle);
  });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.animStyle) {
      updateStyle(changes.animStyle.newValue);
    }
  });

  function updateStyle(styleName) {
    currentStyle = styleName;
    if (frame) {
      frame.className = "ui-searcher-frame frame-" + currentStyle;
    }
  }

  function ensureStyle(){
    if (styleEl) return;
    styleEl = document.createElement("style");
    styleEl.textContent = `
.ui-searcher-frame {
  position:fixed;
  pointer-events:none;
  z-index:2147483647;
  border-radius:0px;
  box-sizing:border-box;
}
.frame-base {
  border: 2px solid #FF4500;
  box-shadow: 0 0 0 9999px rgba(0,0,0,0.4), 0 8px 24px rgba(0,0,0,0.2);
  transition: all 0.2s cubic-bezier(0.2, 0.8, 0.2, 1);
}
.frame-dashed {
  background-image: url("data:image/svg+xml,%3Csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3E%3Cstyle%3E@keyframes march { to { stroke-dashoffset: 24; } } rect { animation: march 0.5s linear infinite; }%3C/style%3E%3Crect width='100%25' height='100%25' fill='none' stroke='%23FF4500' stroke-width='6' stroke-dasharray='12, 12' /%3E%3C/svg%3E");
  box-shadow: 0 0 0 9999px rgba(0,0,0,0.4);
  transition: all 0.15s ease-out;
}
.frame-thick {
  border: 4px solid #111111;
  box-shadow: 6px 6px 0 #FF4500, 0 0 0 9999px rgba(0,0,0,0.4);
  transition: all 0.15s cubic-bezier(0.2, 0.8, 0.2, 1);
}
@keyframes brutal-pulse {
  0% { box-shadow: 0 0 0 9999px rgba(0,0,0,0.4), 0 0 0 0 rgba(255,69,0,0.7); }
  100% { box-shadow: 0 0 0 9999px rgba(0,0,0,0.4), 0 0 0 16px rgba(255,69,0,0); }
}
.frame-pulse {
  border: 2px solid #FF4500;
  animation: brutal-pulse 1s infinite;
  transition: left 0.15s ease-out, top 0.15s ease-out, width 0.15s ease-out, height 0.15s ease-out;
}
.frame-target {
  background: 
    linear-gradient(to right, #FF4500 4px, transparent 4px) 0 0,
    linear-gradient(to right, #FF4500 4px, transparent 4px) 0 100%,
    linear-gradient(to left, #FF4500 4px, transparent 4px) 100% 0,
    linear-gradient(to left, #FF4500 4px, transparent 4px) 100% 100%,
    linear-gradient(to bottom, #FF4500 4px, transparent 4px) 0 0,
    linear-gradient(to bottom, #FF4500 4px, transparent 4px) 100% 0,
    linear-gradient(to top, #FF4500 4px, transparent 4px) 0 100%,
    linear-gradient(to top, #FF4500 4px, transparent 4px) 100% 100%;
  background-repeat: no-repeat;
  background-size: 20px 20px;
  box-shadow: 0 0 0 9999px rgba(0,0,0,0.4);
  transition: all 0.15s cubic-bezier(0.2, 0.8, 0.2, 1);
}
.frame-crosshair {
  border: 1px solid #FF4500;
  box-shadow: 
    0 -100vh 0 0 rgba(255, 69, 0, 0.5), 
    0 100vh 0 0 rgba(255, 69, 0, 0.5), 
    -100vw 0 0 0 rgba(255, 69, 0, 0.5), 
    100vw 0 0 0 rgba(255, 69, 0, 0.5), 
    0 0 0 9999px rgba(0,0,0,0.4);
  transition: all 0.15s cubic-bezier(0.2, 0.8, 0.2, 1);
}
.frame-inverted {
  border: 2px solid #FFFFFF;
  backdrop-filter: invert(100%) contrast(150%);
  box-shadow: 0 0 0 9999px rgba(0,0,0,0.8);
  transition: all 0.15s cubic-bezier(0.2, 0.8, 0.2, 1);
}
@keyframes scanline-anim {
  0% { background-position: 0 -100vh; }
  100% { background-position: 0 100vh; }
}
.frame-scanline {
  border: 2px solid #33FF00;
  background: linear-gradient(to bottom, transparent 48%, rgba(51, 255, 0, 0.8) 50%, transparent 52%);
  background-size: 100% 200vh;
  animation: scanline-anim 3s linear infinite;
  box-shadow: 0 0 0 9999px rgba(0,10,0,0.8);
  transition: all 0.15s ease-out;
}
@keyframes glitch-border {
  0% { transform: translate(0); border-color: #FF4500; }
  20% { transform: translate(-3px, 3px); border-color: #00FFFF; }
  40% { transform: translate(-3px, -3px); border-color: #FF4500; }
  60% { transform: translate(3px, 3px); border-color: #FF00FF; }
  80% { transform: translate(3px, -3px); border-color: #FF4500; }
  100% { transform: translate(0); border-color: #FF4500; }
}
.frame-glitch {
  border: 4px solid #FF4500;
  animation: glitch-border 0.2s infinite steps(2);
  box-shadow: 0 0 0 9999px rgba(0,0,0,0.4);
  transition: width 0.1s linear, height 0.1s linear, top 0.1s linear, left 0.1s linear;
}
@keyframes hacker-blink {
  0%, 49% { opacity: 1; }
  50%, 100% { opacity: 0; }
}
@keyframes hacker-rain {
  0% { background-position: 0 0; }
  100% { background-position: 0 120px; }
}
.frame-hacker {
  border: 2px solid #00FF00;
  box-shadow: 0 0 0 9999px rgba(0, 10, 0, 0.85), 0 0 10px #00FF00, inset 0 0 10px rgba(0,255,0,0.5);
  background-color: rgba(0, 255, 0, 0.05);
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cstyle%3Etext { font-family: monospace; font-size: 14px; fill: %2300FF00; }%3C/style%3E%3Ctext x='5' y='15' opacity='0.5'%3E0%3C/text%3E%3Ctext x='5' y='45' opacity='0.2'%3E1%3C/text%3E%3Ctext x='5' y='95' opacity='0.6'%3E1%3C/text%3E%3Ctext x='25' y='25' opacity='0.3'%3E1%3C/text%3E%3Ctext x='25' y='65' opacity='0.8'%3E0%3C/text%3E%3Ctext x='25' y='105' opacity='0.4'%3E1%3C/text%3E%3Ctext x='45' y='35' opacity='0.7'%3E0%3C/text%3E%3Ctext x='45' y='85' opacity='0.3'%3E1%3C/text%3E%3Ctext x='65' y='15' opacity='0.4'%3E1%3C/text%3E%3Ctext x='65' y='55' opacity='0.9'%3E0%3C/text%3E%3Ctext x='65' y='115' opacity='0.2'%3E1%3C/text%3E%3Ctext x='85' y='45' opacity='0.5'%3E0%3C/text%3E%3Ctext x='85' y='75' opacity='0.3'%3E1%3C/text%3E%3Ctext x='105' y='25' opacity='0.6'%3E1%3C/text%3E%3Ctext x='105' y='85' opacity='0.8'%3E0%3C/text%3E%3Ctext x='105' y='115' opacity='0.4'%3E1%3C/text%3E%3C/svg%3E");
  background-repeat: repeat;
  animation: hacker-rain 3s linear infinite;
  transition: all 0.1s linear;
}
.frame-hacker::after {
  content: '█';
  position: absolute;
  bottom: -4px;
  right: 4px;
  color: #00FF00;
  font-family: monospace;
  font-size: 24px;
  animation: hacker-blink 1s infinite;
}
.ui-searcher-size {
  position:fixed;
  pointer-events:none;
  z-index:2147483647;
  padding:6px 10px;
  background:#FF4500;
  color:#FFFFFF;
  font-family:'Space Grotesk', sans-serif;
  font-size:12px;
  font-weight:700;
  border-radius:0px;
  letter-spacing: 0.05em;
  border: 2px solid #111111;
  transition: all 0.2s cubic-bezier(0.2, 0.8, 0.2, 1);
}
`;
    document.head.appendChild(styleEl);
  }

  let sizeLabel = null;
  function ensureSizeLabel(){
    if (sizeLabel) return;
    sizeLabel = document.createElement("div");
    sizeLabel.className = "ui-searcher-size";
    document.body.appendChild(sizeLabel);
  }

  function createFrame(rect){
    ensureStyle();
    if (!frame) {
            frame = document.createElement("div");
      frame.className = "ui-searcher-frame frame-" + currentStyle;
      document.body.appendChild(frame);
    }
    frame.style.left = rect.left + "px";
    frame.style.top = rect.top + "px";
    frame.style.width = rect.width + "px";
    frame.style.height = rect.height + "px";

    if (handles.length === 0) {
      for (let i=0;i<8;i++){
        const h = document.createElement("div");
        h.className = "ui-searcher-handle";
        document.body.appendChild(h);
        handles.push(h);
      }
    }
    const pts = [
      [rect.left, rect.top],
      [rect.left + rect.width/2, rect.top],
      [rect.left + rect.width, rect.top],
      [rect.left, rect.top + rect.height/2],
      [rect.left + rect.width, rect.top + rect.height/2],
      [rect.left, rect.top + rect.height],
      [rect.left + rect.width/2, rect.top + rect.height],
      [rect.left + rect.width, rect.top + rect.height],
    ];
    handles.forEach((h,i)=>{
      h.style.left = (pts[i][0] - 4) + "px";
      h.style.top  = (pts[i][1] - 4) + "px";
    });

        ensureSizeLabel();
    sizeLabel.textContent = Math.round(rect.width) + " x " + Math.round(rect.height);
    sizeLabel.style.left = rect.left + "px";
    sizeLabel.style.top  = (rect.top - 24) + "px";
  }

  function clearFrame(){
    frame && frame.remove();
    frame = null;
    handles.forEach(h => h.remove());
    handles = [];
    if (sizeLabel){ sizeLabel.remove(); sizeLabel = null; }
  }

  function findElement(el){
    let n = el;
    while (n && n !== document.body && n !== document.documentElement) {
      const r = n.getBoundingClientRect();
      if (r.width > 16 && r.height > 16) return n;
      n = n.parentElement;
    }
    return el;
  }

  function move(e){
    if (mode !== "element") return;
    const el = findElement(e.target);
    const r = el.getBoundingClientRect();
    createFrame(r);
  }

  async function safeCaptureVisible() {
    let retries = 5;
    while (retries > 0) {
      const res = await new Promise(r => chrome.runtime.sendMessage({type: "capture-visible"}, r));
      if (res && res.success) return res;
      await new Promise(r => setTimeout(r, 500));
      retries--;
    }
    return null;
  }

  async function captureElementStitched(el) {
    const dpr = window.devicePixelRatio || 1;
    const clientWidth = document.documentElement.clientWidth;
    const clientHeight = document.documentElement.clientHeight;
    
    el.scrollIntoView({ behavior: "instant", block: "nearest", inline: "nearest" });
    const rect = el.getBoundingClientRect();
    
    if (rect.top >= 0 && rect.left >= 0 && rect.bottom <= clientHeight && rect.right <= clientWidth) {
       await new Promise(r => setTimeout(r, 350));
       const res = await safeCaptureVisible();
       if (res && res.success) {
         const img = new Image();
         img.src = res.screenshot;
         await new Promise(r => { img.onload = r; });
         
         const canvas = document.createElement("canvas");
         canvas.width = rect.width * dpr;
         canvas.height = rect.height * dpr;
         const ctx = canvas.getContext("2d");
         ctx.drawImage(img, rect.left * dpr, rect.top * dpr, rect.width * dpr, rect.height * dpr, 0, 0, rect.width * dpr, rect.height * dpr);
         return canvas;
       }
    }
    
    const originalX = window.scrollX;
    const originalY = window.scrollY;

    const startX = originalX + rect.left;
    const startY = originalY + rect.top;
    const totalW = rect.width;
    const totalH = rect.height;

    const canvas = document.createElement("canvas");
    canvas.width = totalW * dpr;
    canvas.height = totalH * dpr;
    const ctx = canvas.getContext("2d");

    const fixedElements = [];
    const allEls = document.querySelectorAll('*');
    for (let node of allEls) {
      const style = window.getComputedStyle(node);
      if (style.position === 'fixed' || style.position === 'sticky') {
        fixedElements.push({ el: node, position: node.style.position, transition: node.style.transition });
        node.style.transition = 'none';
        node.style.position = 'absolute';
      }
    }

    const noScrollbarStyle = document.createElement('style');
    noScrollbarStyle.innerHTML = '::-webkit-scrollbar { display: none !important; } * { scrollbar-width: none !important; }';
    document.head.appendChild(noScrollbarStyle);

    await new Promise(r => setTimeout(r, 350));

    let y = startY;
    while (y < startY + totalH) {
      let x = startX;
      while (x < startX + totalW) {
        window.scrollTo(x, y);
        await new Promise(r => setTimeout(r, 250));

        const res = await safeCaptureVisible();
        if (res && res.success) {
          const img = new Image();
          img.src = res.screenshot;
          await new Promise(r => { img.onload = r; });
          
          const currentX = window.scrollX;
          const currentY = window.scrollY;
          
          const destX = (currentX - startX) * dpr;
          const destY = (currentY - startY) * dpr;
          
          ctx.drawImage(img, destX, destY, clientWidth * dpr, clientHeight * dpr);
        }
        x += clientWidth;
      }
      y += clientHeight;
    }

    window.scrollTo(originalX, originalY);
    noScrollbarStyle.remove();
    
    for (let item of fixedElements) {
      item.el.style.position = item.position;
      setTimeout(() => { item.el.style.transition = item.transition; }, 50);
    }
    
    return canvas;
  }

    document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && mode === "element") {
      e.preventDefault();
      e.stopPropagation();
      clearFrame();
      mode = null;
      document.removeEventListener("mousemove", move, true);
      document.removeEventListener("click", click, true);
    }
  }, true);

  async function click(e){
    if (mode !== "element") return;
    e.preventDefault();
    e.stopPropagation();

    const el = findElement(e.target);
    const dpr = window.devicePixelRatio || 1;

    clearFrame();
    mode = null;
    document.removeEventListener("mousemove", move, true);
    document.removeEventListener("click", click, true);

    const rawCanvas = await captureElementStitched(el);
    if (!rawCanvas) return;

    const padding = 120 * dpr;
    const finalCanvas = document.createElement("canvas");
    finalCanvas.width = rawCanvas.width + padding * 2;
    finalCanvas.height = rawCanvas.height + padding * 2;
    const ctx = finalCanvas.getContext("2d");

    ctx.fillStyle = '#EAE8E3';
    ctx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);
    
    ctx.shadowColor = 'rgba(0,0,0,0.15)';
    ctx.shadowBlur = 40 * dpr;
    ctx.shadowOffsetY = 20 * dpr;

    ctx.drawImage(rawCanvas, padding, padding);

    chrome.runtime.sendMessage({
      type:"save-image",
      fileName:"screenshot-" + Date.now() + ".png",
      dataUrl:finalCanvas.toDataURL("image/png", 1.0)
    });
  }

  async function captureFullPage() {
    const dpr = window.devicePixelRatio || 1;
    const clientWidth = document.documentElement.clientWidth;
    const clientHeight = document.documentElement.clientHeight;
    const scrollWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth, document.body.offsetWidth, document.documentElement.offsetWidth, document.documentElement.clientWidth);
    const scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.documentElement.clientHeight);

    const canvas = document.createElement("canvas");
    canvas.width = scrollWidth * dpr;
    canvas.height = scrollHeight * dpr;
    const ctx = canvas.getContext("2d");

    const originalX = window.scrollX;
      const originalY = window.scrollY;
  
      // Pre-scroll the page to trigger lazy loading and animations
      let preY = 0;
      while (preY < scrollHeight) {
        window.scrollTo(0, preY);
        await new Promise(r => setTimeout(r, 150));
        preY += clientHeight;
      }
      window.scrollTo(0, scrollHeight);
      await new Promise(r => setTimeout(r, 400));
      window.scrollTo(0, 0);
      await new Promise(r => setTimeout(r, 500));
  
      const fixedElements = [];
    const allEls = document.querySelectorAll('*');
    for (let el of allEls) {
      const style = window.getComputedStyle(el);
      if (style.position === 'fixed' || style.position === 'sticky') {
        fixedElements.push({ el: el, position: el.style.position, transition: el.style.transition });
        el.style.transition = 'none';
        el.style.position = 'absolute';
      }
    }

    const noScrollbarStyle = document.createElement('style');
    noScrollbarStyle.innerHTML = '::-webkit-scrollbar { display: none !important; } * { scrollbar-width: none !important; }';
    document.head.appendChild(noScrollbarStyle);

    let y = 0;
    while (y < scrollHeight) {
      let x = 0;
      while (x < scrollWidth) {
        window.scrollTo(x, y);
        await new Promise(r => setTimeout(r, 250));

        const res = await safeCaptureVisible();
        if (res && res.success) {
          const img = new Image();
          img.src = res.screenshot;
          await new Promise(r => { img.onload = r; });
          
          const currentX = window.scrollX;
          const currentY = window.scrollY;
          
          ctx.drawImage(img, currentX * dpr, currentY * dpr, clientWidth * dpr, clientHeight * dpr);
        }
        x += clientWidth;
      }
      y += clientHeight;
    }

    window.scrollTo(originalX, originalY);
    noScrollbarStyle.remove();
    
    for (let item of fixedElements) {
      item.el.style.position = item.position;
      setTimeout(() => { item.el.style.transition = item.transition; }, 50);
    }

    chrome.runtime.sendMessage({
      type: "save-image",
      fileName: "screenshot-" + Date.now() + ".png",
      dataUrl: canvas.toDataURL("image/png", 1.0)
    });
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "capture-element") {
      mode = "element";
      document.addEventListener("mousemove", move, true);
      document.addEventListener("click", click, true);
      sendResponse({received: true});
    } else if (msg.type === "capture-visible") {
      setTimeout(async () => { 
        const res = await safeCaptureVisible();
        if (res && res.success) {
          chrome.runtime.sendMessage({
            type: "save-image",
            fileName: "screenshot-" + Date.now() + ".png",
            dataUrl: res.screenshot
          });
        }
      }, 350);
      sendResponse({received: true});
    } else if (msg.type === "capture-page") {
      setTimeout(() => {
        captureFullPage();
      }, 350);
      sendResponse({received: true});
    }
    return true;
  });

})();











