chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "capture-visible") {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        sendResponse({ success: false, error: chrome.runtime.lastError.message });
      } else {
        sendResponse({ success: true, screenshot: dataUrl });
      }
    });
    return true; // Keep channel open for async response
  }
  
        if (msg.type === "save-image") {
    chrome.downloads.download({
      url: msg.dataUrl,
      filename: msg.fileName || "screenshot.png",
      saveAs: false
    });
    sendResponse({ success: true });
    return true;
  }
});

chrome.commands.onCommand.addListener((command) => {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs && tabs[0]) {
      let type = "";
      if (command === "capture_element") type = "capture-element";
      if (command === "capture_visible") type = "capture-visible";
      if (command === "capture_page") type = "capture-page";
      
      if (command === "detach_window") {
        const popupUrl = chrome.runtime.getURL('popup.html');
        chrome.tabs.query({url: popupUrl}, (tabs) => {
          if (tabs.length > 0) {
            chrome.windows.update(tabs[0].windowId, {focused: true});
          } else {
            chrome.windows.create({
              url: 'popup.html',
              type: 'popup',
              width: 336,
              height: 485,
              focused: true
            });
          }
        });
        return;
      }
      
      if (type) {
        chrome.tabs.sendMessage(tabs[0].id, {type: type}).catch(() => {});
      }
    }
  });
});



